export interface Theme {
  id: number;
  title: string;
  content: string;
  keywords: string[];
}

export interface Guide {
  id: number;
  title: string;
  description: string;
  imageUrl: string;
  downloadUrl: string;
}

export interface Prompt {
  id: number;
  category: string;
  title: string;
  description: string;
  template: string;
  examples: string[];
}

export interface ContentTip {
  id: number;
  title: string;
  description: string;
  steps: string[];
  imageUrl: string;
}

export interface BusinessResource {
  id: number;
  title: string;
  description: string;
  steps: string[];
  imageUrl: string;
}

export interface WebResource {
  id: number;
  title: string;
  description: string;
  tools: string[];
  imageUrl: string;
}