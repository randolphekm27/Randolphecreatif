import axios from 'axios';

const API_KEY = import.meta.env.VITE_OPENAI_API_KEY;

export async function generateSpeech(text: string): Promise<Blob> {
  try {
    const response = await axios.post(
      'https://api.openai.com/v1/audio/speech',
      {
        model: 'tts-1',
        input: text,
        voice: 'alloy',
      },
      {
        headers: {
          'Authorization': `Bearer ${API_KEY}`,
          'Content-Type': 'application/json',
        },
        responseType: 'blob',
      }
    );
    return response.data;
  } catch (error) {
    console.error('Error generating speech:', error);
    throw new Error('Failed to generate speech');
  }
}