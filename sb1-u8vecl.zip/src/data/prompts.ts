import { Prompt } from '../types';

export const prompts: Prompt[] = [
  {
    id: 1,
    category: "Copywriting",
    title: "Accroche Persuasive",
    description: "Créez des accroches qui captivent instantanément",
    template: "Écris une accroche persuasive pour [produit/service] qui cible [audience] en mettant l'accent sur [bénéfice principal]",
    examples: [
      "Découvrez comment doubler vos revenus en 30 jours avec notre formation business",
      "Transformez votre passion en business rentable dès aujourd'hui"
    ]
  },
  {
    id: 2,
    category: "Marketing",
    title: "Description Produit",
    description: "Générez des descriptions de produits convaincantes",
    template: "Crée une description de produit pour [produit] qui met en avant [caractéristiques principales] et résout [problème client]",
    examples: [
      "La formation ultime en IA qui vous propulse de débutant à expert en 12 semaines",
      "Le guide complet du freelancing qui transforme votre expertise en revenus"
    ]
  },
  {
    id: 3,
    category: "SEO",
    title: "Optimisation SEO",
    description: "Optimisez vos contenus pour les moteurs de recherche",
    template: "Optimise ce texte pour le mot-clé [mot-clé] tout en gardant un style naturel et engageant",
    examples: [
      "Comment devenir freelance en 2024: Le guide ultime pour réussir",
      "Formation IA: Maîtrisez l'intelligence artificielle en 2024"
    ]
  }
];