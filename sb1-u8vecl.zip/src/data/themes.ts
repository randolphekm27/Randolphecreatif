import { Theme } from '../types';

export const themes: Theme[] = [
  {
    id: 1,
    title: "Introduction à l'IA",
    content: "Découvrez les concepts fondamentaux de l'intelligence artificielle et son impact sur notre société moderne. Explorez les différentes applications et perspectives d'avenir.",
    keywords: ["IA", "Intelligence Artificielle", "Technologie"]
  },
  {
    id: 2,
    title: "Business en Ligne",
    content: "Apprenez les stratégies essentielles pour créer et développer votre présence en ligne. Des conseils pratiques pour réussir dans l'entrepreneuriat digital.",
    keywords: ["Business", "Entrepreneur", "Digital"]
  },
  {
    id: 3,
    title: "L'Art du Prompt Engineering",
    content: "Maîtrisez l'art de créer des prompts efficaces pour l'IA. Techniques avancées et meilleures pratiques pour optimiser vos résultats.",
    keywords: ["Prompt", "IA", "Engineering"]
  },
  {
    id: 4,
    title: "SEO pour débutants",
    content: "Découvrez les bases du SEO pour améliorer la visibilité de votre site sur les moteurs de recherche. Conseils pour optimiser le contenu et attirer plus de visiteurs.",
    keywords: ["SEO", "Référencement", "Visibilité"]
  },
  {
    id: 5,
    title: "Social Media Marketing",
    content: "Explorez les stratégies pour créer un impact sur les réseaux sociaux et bâtir une communauté engagée. Apprenez à gérer et optimiser votre présence en ligne pour attirer et fidéliser votre audience.",
    keywords: ["Marketing", "Réseaux Sociaux", "Engagement"]
  },
  {
    id: 6,
    title: "Création de Contenu Impactant",
    content: "Les techniques clés pour créer du contenu captivant et engageant. Découvrez comment écrire des articles, vidéos et images qui attirent l'attention et encouragent les interactions.",
    keywords: ["Content", "Création", "Engagement"]
  }
];