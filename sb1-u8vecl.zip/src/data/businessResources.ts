import { BusinessResource } from '../types';

export const businessResources: BusinessResource[] = [
  {
    id: 1,
    title: "Lancer Son Business en Ligne",
    description: "De l'idée au premier client, je vous guide pas à pas",
    steps: [
      "Trouvez votre niche parfaite",
      "Créez votre offre irrésistible",
      "Attirez vos clients idéaux",
      "Automatisez vos ventes"
    ],
    imageUrl: "https://images.unsplash.com/photo-1460925895917-afdab827c52f"
  },
  {
    id: 2,
    title: "Stratégie de Personal Branding",
    description: "Construisez une marque personnelle qui vous démarque",
    steps: [
      "Définissez votre message unique",
      "Créez du contenu qui résonne",
      "Développez votre présence en ligne",
      "Monétisez votre expertise"
    ],
    imageUrl: "https://images.unsplash.com/photo-1493612276216-ee3925520721"
  }
];