import { Guide } from '../types';

export const guides: Guide[] = [
  {
    id: 1,
    title: "Prompt-Guide",
    description: "Guide complet pour maîtriser l'art du prompt engineering avec l'IA",
    imageUrl: "https://images.unsplash.com/photo-1677442136019-21780ecad995",
    downloadUrl: "/guides/prompt-guide.pdf"
  },
  {
    id: 2,
    title: "SEO-Marketing",
    description: "Stratégies avancées pour optimiser votre présence en ligne",
    imageUrl: "https://images.unsplash.com/photo-1432888622747-4eb9a8f2c293",
    downloadUrl: "/guides/seo-marketing.pdf"
  },
  {
    id: 3,
    title: "Guide Pour rédaction web",
    description: "Techniques professionnelles pour une rédaction web efficace",
    imageUrl: "https://images.unsplash.com/photo-1455390582262-044cdead277a",
    downloadUrl: "/guides/redaction-web.pdf"
  },
  {
    id: 4,
    title: "Guide du Freelance",
    description: "Tout ce dont vous avez besoin pour réussir en tant que freelance",
    imageUrl: "https://images.unsplash.com/photo-1499750310107-5fef28a66643",
    downloadUrl: "/guides/freelance.pdf"
  },
  {
    id: 5,
    title: "Maître de l'IA",
    description: "Guide complet pour maîtriser l'intelligence artificielle",
    imageUrl: "https://images.unsplash.com/photo-1677442136019-21780ecad995",
    downloadUrl: "/guides/ia-master.pdf"
  }
];