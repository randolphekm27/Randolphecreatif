import { ContentTip } from '../types';

export const contentTips: ContentTip[] = [
  {
    id: 1,
    title: "L'Art du Storytelling Digital",
    description: "Captivez votre audience avec des histoires mémorables",
    steps: [
      "Identifiez votre héros (votre audience)",
      "Définissez le problème central",
      "Présentez le voyage de transformation",
      "Partagez les résultats inspirants"
    ],
    imageUrl: "https://images.unsplash.com/photo-1516383740770-fbcc5ccbece0"
  },
  {
    id: 2,
    title: "Copywriting Émotionnel",
    description: "Créez une connexion profonde avec votre audience",
    steps: [
      "Utilisez des mots qui évoquent des émotions",
      "Racontez des histoires personnelles",
      "Créez un sentiment d'urgence",
      "Finissez par un appel à l'action puissant"
    ],
    imageUrl: "https://images.unsplash.com/photo-1455390582262-044cdead277a"
  }
];