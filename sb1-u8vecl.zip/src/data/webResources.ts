import { WebResource } from '../types';

export const webResources: WebResource[] = [
  {
    id: 1,
    title: "Développement Web Moderne",
    description: "Maîtrisez les technologies web les plus demandées",
    tools: [
      "React & Next.js",
      "Tailwind CSS",
      "TypeScript",
      "Node.js"
    ],
    imageUrl: "https://images.unsplash.com/photo-1461749280684-dccba630e2f6"
  },
  {
    id: 2,
    title: "Design UI/UX",
    description: "Créez des interfaces utilisateur exceptionnelles",
    tools: [
      "Figma",
      "Adobe XD",
      "Principes de design",
      "Tests utilisateurs"
    ],
    imageUrl: "https://images.unsplash.com/photo-1507238691740-187a5b1d37b8"
  }
];