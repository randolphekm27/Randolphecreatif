import { motion } from 'framer-motion';
import { contentTips } from '../../data/contentTips';
import { useInView } from 'react-intersection-observer';

export default function ContentSection() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  });

  return (
    <div className="container mx-auto px-4 py-12">
      <motion.h2
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl font-bold text-center mb-12"
      >
        L'Art du Content Making ✍️
      </motion.h2>

      <div ref={ref} className="grid gap-8 md:grid-cols-2">
        {contentTips.map((tip, index) => (
          <motion.div
            key={tip.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={inView ? { opacity: 1, scale: 1 } : {}}
            transition={{ duration: 0.6, delay: index * 0.2 }}
            className="bg-white/5 rounded-lg overflow-hidden hover:bg-white/10 transition-all duration-300"
          >
            <img
              src={tip.imageUrl}
              alt={tip.title}
              className="w-full h-48 object-cover"
            />
            <div className="p-6">
              <h3 className="text-2xl font-bold mb-4">{tip.title}</h3>
              <p className="text-gray-300 mb-6">{tip.description}</p>
              <ol className="space-y-3">
                {tip.steps.map((step, stepIndex) => (
                  <li key={stepIndex} className="flex items-start gap-3">
                    <span className="font-bold text-emerald-400">
                      {stepIndex + 1}.
                    </span>
                    {step}
                  </li>
                ))}
              </ol>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}