import { motion } from 'framer-motion';
import { prompts } from '../../data/prompts';
import { useState } from 'react';

export default function PromptSection() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const categories = Array.from(new Set(prompts.map(prompt => prompt.category)));
  const filteredPrompts = selectedCategory
    ? prompts.filter(prompt => prompt.category === selectedCategory)
    : prompts;

  return (
    <div className="container mx-auto px-4 py-12">
      <motion.h2
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl font-bold text-center mb-12"
      >
        Bibliothèque de Prompts 🤖
      </motion.h2>

      <div className="flex justify-center gap-4 mb-8">
        <button
          onClick={() => setSelectedCategory(null)}
          className={`px-4 py-2 rounded-full transition-colors duration-300 
            ${!selectedCategory ? 'bg-white text-black' : 'bg-white/10 text-white'}`}
        >
          Tous
        </button>
        {categories.map(category => (
          <button
            key={category}
            onClick={() => setSelectedCategory(category)}
            className={`px-4 py-2 rounded-full transition-colors duration-300 
              ${selectedCategory === category ? 'bg-white text-black' : 'bg-white/10 text-white'}`}
          >
            {category}
          </button>
        ))}
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {filteredPrompts.map((prompt, index) => (
          <motion.div
            key={prompt.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            className="bg-white/5 rounded-lg p-6 hover:bg-white/10 transition-all duration-300"
          >
            <span className="inline-block px-3 py-1 bg-white/10 rounded-full text-sm mb-4">
              {prompt.category}
            </span>
            <h3 className="text-xl font-bold mb-4">{prompt.title}</h3>
            <p className="text-gray-300 mb-4">{prompt.description}</p>
            <div className="bg-white/5 p-4 rounded-lg mb-4">
              <p className="font-mono text-sm">{prompt.template}</p>
            </div>
            <div className="space-y-2">
              {prompt.examples.map((example, i) => (
                <p key={i} className="text-sm text-gray-400">
                  • {example}
                </p>
              ))}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}