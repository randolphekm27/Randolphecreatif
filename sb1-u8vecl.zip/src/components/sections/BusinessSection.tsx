import { motion } from 'framer-motion';
import { businessResources } from '../../data/businessResources';
import { useInView } from 'react-intersection-observer';

export default function BusinessSection() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  });

  return (
    <div className="container mx-auto px-4 py-12">
      <motion.h2
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl font-bold text-center mb-12"
      >
        Développez Votre Business en Ligne 🚀
      </motion.h2>

      <div ref={ref} className="grid gap-8 md:grid-cols-2">
        {businessResources.map((resource, index) => (
          <motion.div
            key={resource.id}
            initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: index * 0.2 }}
            className="bg-white/5 rounded-lg p-6 hover:bg-white/10 transition-all duration-300"
          >
            <img
              src={resource.imageUrl}
              alt={resource.title}
              className="w-full h-48 object-cover rounded-lg mb-6"
            />
            <h3 className="text-2xl font-bold mb-4">{resource.title}</h3>
            <p className="text-gray-300 mb-6">{resource.description}</p>
            <ul className="space-y-3">
              {resource.steps.map((step, stepIndex) => (
                <li key={stepIndex} className="flex items-center gap-3">
                  <span className="text-emerald-400">✓</span>
                  {step}
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </div>
  );
}