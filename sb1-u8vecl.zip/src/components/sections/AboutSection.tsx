import { motion } from 'framer-motion';
import ContactInfo from '../ContactInfo';
import TextToSpeech from '../TextToSpeech';

export default function AboutSection() {
  return (
    <div className="container mx-auto px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-3xl mx-auto"
      >
        <div className="text-center">
          <img
            src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e"
            alt="Randolphe KM"
            className="w-48 h-48 rounded-full mx-auto mb-8 border-4 border-white"
          />
          <h2 className="text-4xl font-bold mb-6">Salut, moi c'est Randolphe! 👋</h2>
          <p className="text-xl text-gray-300 mb-8">
            Passionné par l'IA et le business en ligne, j'aide les entrepreneurs à exploiter
            la puissance de la technologie pour développer leur activité. Mon objectif ?
            Rendre l'IA accessible à tous et transformer vos idées en succès!
          </p>
        </div>

        <div className="space-y-6 bg-white/5 p-8 rounded-lg mb-8">
          <h3 className="text-2xl font-bold">Mon Parcours</h3>
          <p className="text-gray-300">
            Après plusieurs années dans le développement web et l'IA, j'ai décidé de
            partager mon expertise pour aider d'autres entrepreneurs à réussir dans
            le digital. Je crois fermement que la technologie, bien utilisée, peut
            transformer n'importe quelle passion en business rentable.
          </p>
        </div>

        <TextToSpeech />
        <ContactInfo />
      </motion.div>
    </div>
  );
}