import { motion } from 'framer-motion';
import { webResources } from '../../data/webResources';
import { useInView } from 'react-intersection-observer';

export default function WebSection() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  });

  return (
    <div className="container mx-auto px-4 py-12">
      <motion.h2
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl font-bold text-center mb-12"
      >
        Développement Web 💻
      </motion.h2>

      <div ref={ref} className="grid gap-8 md:grid-cols-2">
        {webResources.map((resource, index) => (
          <motion.div
            key={resource.id}
            initial={{ opacity: 0, y: 50 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6, delay: index * 0.2 }}
            className="bg-white/5 rounded-lg overflow-hidden hover:bg-white/10 transition-all duration-300"
          >
            <img
              src={resource.imageUrl}
              alt={resource.title}
              className="w-full h-48 object-cover"
            />
            <div className="p-6">
              <h3 className="text-2xl font-bold mb-4">{resource.title}</h3>
              <p className="text-gray-300 mb-6">{resource.description}</p>
              <div className="flex flex-wrap gap-2">
                {resource.tools.map((tool, toolIndex) => (
                  <span
                    key={toolIndex}
                    className="px-3 py-1 bg-white/10 rounded-full text-sm"
                  >
                    {tool}
                  </span>
                ))}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}