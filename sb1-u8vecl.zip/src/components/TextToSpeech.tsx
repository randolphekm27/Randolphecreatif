import { useState } from 'react';
import { motion } from 'framer-motion';
import { Volume2, Download, Loader, AlertCircle } from 'lucide-react';
import { generateSpeech } from '../utils/api';

export default function TextToSpeech() {
  const [text, setText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleGenerateSpeech = async () => {
    if (!text) return;
    
    setIsLoading(true);
    setError(null);
    try {
      const audioBlob = await generateSpeech(text);
      const url = URL.createObjectURL(audioBlob);
      setAudioUrl(url);
    } catch (err) {
      setError('Une erreur est survenue lors de la génération de la voix. Veuillez réessayer.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-6 bg-white/5 rounded-lg">
      <h3 className="text-2xl font-bold mb-4 flex items-center gap-2">
        <Volume2 className="text-emerald-400" />
        Convertisseur Texte en Voix
      </h3>
      
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Entrez votre texte ici..."
        className="w-full h-32 p-4 bg-white/10 rounded-lg text-white placeholder-gray-400 resize-none focus:outline-none focus:ring-2 focus:ring-emerald-400 mb-4"
      />

      {error && (
        <div className="mb-4 p-4 bg-red-500/10 border border-red-500/20 rounded-lg flex items-center gap-2 text-red-400">
          <AlertCircle size={20} />
          {error}
        </div>
      )}

      <div className="flex justify-between items-center">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={handleGenerateSpeech}
          disabled={isLoading || !text}
          className="px-6 py-2 bg-emerald-500 text-white rounded-full flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoading ? <Loader className="animate-spin" /> : <Volume2 />}
          Générer la voix
        </motion.button>

        {audioUrl && (
          <motion.a
            href={audioUrl}
            download="audio.mp3"
            className="px-6 py-2 bg-white/10 text-white rounded-full flex items-center gap-2 hover:bg-white/20 transition-colors"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Download size={20} />
            Télécharger
          </motion.a>
        )}
      </div>

      {audioUrl && (
        <div className="mt-4">
          <audio controls className="w-full">
            <source src={audioUrl} type="audio/mpeg" />
            Votre navigateur ne supporte pas l'élément audio.
          </audio>
        </div>
      )}
    </div>
  );
}