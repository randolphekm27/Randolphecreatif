import { motion } from 'framer-motion';
import { Phone, Mail, MessageCircle, Facebook } from 'lucide-react';

export default function ContactInfo() {
  const contacts = [
    {
      icon: Phone,
      label: 'Téléphone',
      value: '+229 0157703972',
      href: 'tel:+2290157703972'
    },
    {
      icon: Mail,
      label: 'Email',
      value: 'randolphekm@gmail.com',
      href: 'mailto:randolphekm@gmail.com'
    },
    {
      icon: MessageCircle,
      label: 'Telegram',
      value: 'Chaîne privée IA',
      href: 'https://t.me/+cSPYdq_NfuE5ZDQ0'
    },
    {
      icon: MessageCircle,
      label: 'WhatsApp',
      value: 'Meta Business Blueprint',
      href: 'https://chat.whatsapp.com/E6yQM5sRxdJ1YQavcw3sBI'
    },
    {
      icon: Facebook,
      label: 'Facebook',
      value: 'Randolphe KM',
      href: 'https://www.facebook.com/profile.php?id=100049637839098'
    }
  ];

  return (
    <div className="max-w-2xl mx-auto p-6 bg-white/5 rounded-lg mt-8">
      <h3 className="text-2xl font-bold mb-6">Contactez-moi</h3>
      
      <div className="space-y-4">
        {contacts.map((contact, index) => (
          <motion.a
            key={index}
            href={contact.href}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-4 p-4 bg-white/5 rounded-lg hover:bg-white/10 transition-colors"
            whileHover={{ x: 10 }}
          >
            <contact.icon className="text-emerald-400" size={24} />
            <div>
              <p className="text-sm text-gray-400">{contact.label}</p>
              <p className="text-white">{contact.value}</p>
            </div>
          </motion.a>
        ))}
      </div>
    </div>
  );
}