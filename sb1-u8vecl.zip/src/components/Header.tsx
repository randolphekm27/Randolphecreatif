import { motion } from 'framer-motion';
import { Brain, BookOpen, Code, MessageSquare, Globe, PenTool, BookMarked, User } from 'lucide-react';

interface HeaderProps {
  activeSection: string;
  onSectionChange: (section: string) => void;
}

const navItems = [
  { id: 'accueil', label: 'Accueil', icon: Brain },
  { id: 'business', label: 'Business', icon: BookOpen },
  { id: 'ia', label: 'IA', icon: Code },
  { id: 'prompt', label: 'Prompt', icon: MessageSquare },
  { id: 'web', label: 'Web', icon: Globe },
  { id: 'content', label: 'Content Making', icon: PenTool },
  { id: 'guide', label: 'Guide', icon: BookMarked },
  { id: 'aPropos', label: 'À propos', icon: User }
];

export default function Header({ activeSection, onSectionChange }: HeaderProps) {
  return (
    <header className="bg-gradient-to-b from-black/80 to-black/60 py-8">
      <div className="container mx-auto px-4">
        <motion.div 
          className="flex flex-col items-center gap-4"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <img
            src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e"
            alt="Randolphe KM"
            className="w-32 h-32 rounded-full border-4 border-white object-cover hover:scale-105 transition-transform duration-300"
          />
          <h1 className="text-3xl font-bold text-white">Randolphe KM</h1>
          <p className="text-gray-300">Spécialiste en IA & Business en Ligne</p>
        </motion.div>

        <nav className="mt-8">
          <ul className="flex flex-wrap justify-center gap-4">
            {navItems.map(({ id, label, icon: Icon }) => (
              <motion.li
                key={id}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <button
                  onClick={() => onSectionChange(id)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-full transition-colors duration-300
                    ${activeSection === id 
                      ? 'bg-white text-black' 
                      : 'text-white hover:bg-white/10'
                    }`}
                >
                  <Icon size={18} />
                  {label}
                </button>
              </motion.li>
            ))}
          </ul>
        </nav>
      </div>
    </header>
  );
}