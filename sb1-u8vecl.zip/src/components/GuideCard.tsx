import { motion } from 'framer-motion';
import { Download } from 'lucide-react';
import { Guide } from '../types';

interface GuideCardProps {
  guide: Guide;
  index: number;
}

export default function GuideCard({ guide, index }: GuideCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="bg-white/5 rounded-lg overflow-hidden hover:bg-white/10 transition-all duration-300 transform hover:scale-105"
    >
      <div className="aspect-w-16 aspect-h-9 relative">
        <img
          src={guide.imageUrl}
          alt={guide.title}
          className="w-full h-48 object-cover"
        />
      </div>
      <div className="p-6 space-y-4">
        <h3 className="text-xl font-semibold text-white">{guide.title}</h3>
        <p className="text-gray-300">{guide.description}</p>
        <a
          href={guide.downloadUrl}
          download
          className="inline-flex items-center gap-2 px-4 py-2 bg-white text-black rounded-full hover:bg-gray-100 transition-colors duration-300"
        >
          <Download size={18} />
          Je prends ça
        </a>
      </div>
    </motion.div>
  );
}