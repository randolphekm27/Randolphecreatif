import { motion } from 'framer-motion';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { useState } from 'react';
import { Theme } from '../types';

interface ThemeCardProps {
  theme: Theme;
  index: number;
}

export default function ThemeCard({ theme, index }: ThemeCardProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="bg-white/5 rounded-lg p-6 hover:bg-white/10 transition-colors duration-300"
    >
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full flex items-center justify-between"
      >
        <h3 className="text-xl font-semibold text-white">{theme.title}</h3>
        {isExpanded ? <ChevronUp /> : <ChevronDown />}
      </button>

      <motion.div
        initial={false}
        animate={{ height: isExpanded ? 'auto' : 0, opacity: isExpanded ? 1 : 0 }}
        transition={{ duration: 0.3 }}
        className="overflow-hidden"
      >
        <div className="pt-4 space-y-4">
          <p className="text-gray-300">{theme.content}</p>
          <div className="flex flex-wrap gap-2">
            {theme.keywords.map((keyword) => (
              <span
                key={keyword}
                className="px-3 py-1 bg-white/10 rounded-full text-sm text-white"
              >
                {keyword}
              </span>
            ))}
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}