import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Header from './components/Header';
import SearchBar from './components/SearchBar';
import ThemeCard from './components/ThemeCard';
import GuideCard from './components/GuideCard';
import BusinessSection from './components/sections/BusinessSection';
import PromptSection from './components/sections/PromptSection';
import ContentSection from './components/sections/ContentSection';
import WebSection from './components/sections/WebSection';
import AboutSection from './components/sections/AboutSection';
import { themes } from './data/themes';
import { guides } from './data/guides';

function App() {
  const [activeSection, setActiveSection] = useState('accueil');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredThemes = themes.filter(theme => 
    theme.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    theme.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
    theme.keywords.some(keyword => keyword.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const renderSection = () => {
    switch (activeSection) {
      case 'business':
        return <BusinessSection />;
      case 'prompt':
        return <PromptSection />;
      case 'content':
        return <ContentSection />;
      case 'web':
        return <WebSection />;
      case 'aPropos':
        return <AboutSection />;
      case 'guide':
        return (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="container mx-auto px-4 py-8"
          >
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {guides.map((guide, index) => (
                <GuideCard key={guide.id} guide={guide} index={index} />
              ))}
            </div>
          </motion.div>
        );
      default:
        return (
          <>
            <SearchBar value={searchTerm} onChange={setSearchTerm} />
            <div className="container mx-auto px-4 py-8">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {filteredThemes.map((theme, index) => (
                  <ThemeCard key={theme.id} theme={theme} index={index} />
                ))}
              </div>
            </div>
          </>
        );
    }
  };

  return (
    <div className="min-h-screen bg-black text-white">
      <Header activeSection={activeSection} onSectionChange={setActiveSection} />
      
      <AnimatePresence mode="wait">
        <motion.div
          key={activeSection}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
        >
          {renderSection()}
        </motion.div>
      </AnimatePresence>

      <footer className="bg-white/5 py-8 mt-16">
        <div className="container mx-auto px-4 text-center">
          <p className="text-gray-400">
            Contact : <a href="mailto:contact@exemple.com" className="hover:text-white transition-colors duration-300">
              contact@exemple.com
            </a>
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;